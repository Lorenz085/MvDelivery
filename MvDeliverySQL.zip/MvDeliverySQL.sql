-- ===========================================
-- BANCO: mv_delivery
-- ===========================================
DROP DATABASE IF EXISTS mv_delivery;
CREATE DATABASE mv_delivery
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_0900_ai_ci;

USE mv_delivery;

-- ===========================================
-- CLIENTE
-- ===========================================
CREATE TABLE cliente (
    id_cliente   INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nome         VARCHAR(100) NOT NULL,
    email        VARCHAR(150) NOT NULL,
    telefone     CHAR(11),
    cpf          CHAR(11),
    senha_hash   VARCHAR(255) NOT NULL,
    created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at   DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id_cliente),
    UNIQUE KEY un_cliente_email (email)
);

-- ===========================================
-- RESTAURANTE
-- ===========================================
CREATE TABLE restaurante (
    id_restaurante INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nome           VARCHAR(100) NOT NULL,
    email          VARCHAR(150) NOT NULL,
    telefone       CHAR(11)     NOT NULL,
    tipo_cozinha   VARCHAR(50)  NOT NULL,
    endereco       VARCHAR(255) NOT NULL,
    senha_hash     VARCHAR(255) NOT NULL,
    status         ENUM('ativo','inativo') NOT NULL DEFAULT 'ativo',
    created_at     DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at     DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id_restaurante),
    UNIQUE KEY un_restaurante_email (email),
    UNIQUE KEY un_restaurante_telefone (telefone)
);

-- ===========================================
-- ENDEREÇO DO CLIENTE
-- (usaremos APENAS 1 por cliente, criado no cadastro)
-- ===========================================
CREATE TABLE endereco_cliente (
    id_endereco  INT UNSIGNED NOT NULL AUTO_INCREMENT,
    id_cliente   INT UNSIGNED NOT NULL,
    apelido      VARCHAR(40),
    logradouro   VARCHAR(140) NOT NULL,
    numero       VARCHAR(12)  NOT NULL,
    complemento  VARCHAR(60),
    bairro       VARCHAR(80)  NOT NULL,
    cidade       VARCHAR(80)  NOT NULL,
    uf           CHAR(2)      NOT NULL,
    cep          CHAR(8)      NOT NULL,
    referencia   VARCHAR(140),
    is_principal TINYINT(1) NOT NULL DEFAULT 0,
    created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at   DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id_endereco),
    CONSTRAINT fk_endereco_cliente
      FOREIGN KEY (id_cliente) REFERENCES cliente(id_cliente)
      ON DELETE CASCADE
);

-- ===========================================
-- CARDÁPIO (ITENS)
-- ===========================================
CREATE TABLE cardapio_item (
    id_item        INT UNSIGNED NOT NULL AUTO_INCREMENT,
    id_restaurante INT UNSIGNED NOT NULL,
    nome           VARCHAR(100) NOT NULL,
    descricao      VARCHAR(255),
    categoria      VARCHAR(60),
    preco          DECIMAL(10,2) NOT NULL,
    ativo          TINYINT(1) NOT NULL DEFAULT 1,
    created_at     DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at     DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id_item),
    CONSTRAINT fk_cardapio_rest
      FOREIGN KEY (id_restaurante) REFERENCES restaurante(id_restaurante)
      ON DELETE CASCADE
);

-- ===========================================
-- PEDIDO
-- ===========================================
CREATE TABLE pedido (
    id_pedido          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    id_cliente         INT UNSIGNED NOT NULL,
    id_restaurante     INT UNSIGNED NOT NULL,
    id_endereco        INT UNSIGNED NULL,
    endereco_texto     VARCHAR(255) NOT NULL,
    observacoes        VARCHAR(255),
    status             ENUM('novo','em_preparo','a_caminho','entregue','cancelado')
                       NOT NULL DEFAULT 'novo',
    data_hora          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    subtotal           DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    taxa_entrega       DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    total              DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    codigo_pedido      CHAR(4) NULL,
    PRIMARY KEY (id_pedido),
    CONSTRAINT fk_pedido_cliente
      FOREIGN KEY (id_cliente) REFERENCES cliente(id_cliente),
    CONSTRAINT fk_pedido_restaurante
      FOREIGN KEY (id_restaurante) REFERENCES restaurante(id_restaurante),
    CONSTRAINT fk_pedido_endereco
      FOREIGN KEY (id_endereco) REFERENCES endereco_cliente(id_endereco)
      ON DELETE SET NULL
);

-- ===========================================
-- ITENS DO PEDIDO
-- ===========================================
CREATE TABLE item_pedido (
    id_item_pedido INT UNSIGNED NOT NULL AUTO_INCREMENT,
    id_pedido      INT UNSIGNED NOT NULL,
    id_item        INT UNSIGNED NULL,
    nome_item      VARCHAR(100) NOT NULL,
    quantidade     INT UNSIGNED NOT NULL,
    preco_unitario DECIMAL(10,2) NOT NULL,
    total_linha    DECIMAL(10,2) NOT NULL,
    PRIMARY KEY (id_item_pedido),
    CONSTRAINT fk_item_pedido_pedido
      FOREIGN KEY (id_pedido) REFERENCES pedido(id_pedido)
      ON DELETE CASCADE,
    CONSTRAINT fk_item_pedido_item
      FOREIGN KEY (id_item) REFERENCES cardapio_item(id_item)
      ON DELETE SET NULL
);

-- ===========================================
-- AVALIAÇÃO (OPCIONAL)
-- ===========================================
CREATE TABLE avaliacao (
    id_avaliacao  INT UNSIGNED NOT NULL AUTO_INCREMENT,
    id_pedido     INT UNSIGNED NOT NULL,
    id_cliente    INT UNSIGNED NOT NULL,
    id_restaurante INT UNSIGNED NOT NULL,
    nota          TINYINT UNSIGNED NOT NULL,
    comentario    VARCHAR(255),
    data_hora     DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id_avaliacao),
    CONSTRAINT ck_avaliacao_nota CHECK (nota BETWEEN 1 AND 5),
    CONSTRAINT fk_avaliacao_pedido
      FOREIGN KEY (id_pedido) REFERENCES pedido(id_pedido)
      ON DELETE CASCADE,
    CONSTRAINT fk_avaliacao_cliente
      FOREIGN KEY (id_cliente) REFERENCES cliente(id_cliente),
    CONSTRAINT fk_avaliacao_rest
      FOREIGN KEY (id_restaurante) REFERENCES restaurante(id_restaurante)
);

-- ===========================================
-- SEED: RESTAURANTES E CARDÁPIO
-- ===========================================
INSERT INTO restaurante (nome,email,telefone,tipo_cozinha,endereco,senha_hash)
VALUES
  ('Burger MV','burger@mvdelivery.com','85999990001','Hamburgueria','Av. Principal, 100', '123456'),
  ('Sushi MV','sushi@mvdelivery.com','85999990002','Japonesa','Rua das Flores, 200', '123456');

INSERT INTO cardapio_item (id_restaurante,nome,descricao,categoria,preco)
VALUES
  (1,'Burger Clássico','Pão, carne 150g, queijo, salada','Lanche', 22.90),
  (1,'Batata Frita','Porção individual','Acompanhamento', 9.90),
  (1,'Refrigerante Lata','350ml','Bebida', 6.00),
  (2,'Sushi Combo 12','12 unidades variadas','Combo', 39.90),
  (2,'Temaki Salmão','Temaki grande de salmão','Temaki', 24.90);
