const API = location.origin + "/api";

// Admin fixo (independente de existir no banco)
const ADMIN_EMAIL = "joaopedrom2005@gmail.com";
const ADMIN_PASSWORD = "123456";

const $tipoLogin = document.getElementById("tipoLogin");
const $loginForm = document.getElementById("loginForm");
const $email = document.getElementById("loginEmail");
const $senha = document.getElementById("loginSenha");
const $goCadastro = document.getElementById("goCadastro");

function setSession(data) {
  localStorage.setItem("mvUser", JSON.stringify(data));
}

$goCadastro.addEventListener("click", () => {
  window.location.href = "cadastro.html";
});

$loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const tipo = $tipoLogin.value;
  const email = $email.value.trim();
  const senha = $senha.value.trim();

  if (!email || !senha) {
    alert("Informe e-mail e senha.");
    return;
  }

  // ===== ADMIN =====
  if (tipo === "admin") {
    if (email === ADMIN_EMAIL && senha === ADMIN_PASSWORD) {
      setSession({ role: "admin", email });
      window.location.href = "admin.html";
    } else {
      alert("Credenciais de administrador inválidas.");
    }
    return;
  }

  // ===== CLIENTE =====
  if (tipo === "cliente") {
    try {
      const res = await fetch(`${API}/auth/login-cliente`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, senha })
      });
      const body = await res.json();
      if (!res.ok) {
        alert(body.error || "Não foi possível entrar como cliente.");
        return;
      }
      setSession({
        role: "cliente",
        id: body.id_cliente,
        nome: body.nome,
        email
      });
      window.location.href = "cliente.html";
    } catch (err) {
      console.error(err);
      alert("Erro ao conectar com o servidor.");
    }
    return;
  }

  // ===== RESTAURANTE =====
  if (tipo === "restaurante") {
    try {
      const res = await fetch(`${API}/auth/login-restaurante`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, senha })
      });
      const body = await res.json();
      if (!res.ok) {
        alert(body.error || "Não foi possível entrar como restaurante.");
        return;
      }
      setSession({
        role: "restaurante",
        id: body.id_restaurante,
        nome: body.nome,
        email
      });
      window.location.href = "restaurante.html";
    } catch (err) {
      console.error(err);
      alert("Erro ao conectar com o servidor.");
    }
  }
});
