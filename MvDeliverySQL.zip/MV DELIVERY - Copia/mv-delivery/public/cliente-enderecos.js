const API = location.origin + "/api";

// ======= VERIFICA SE É CLIENTE =======
const user = JSON.parse(localStorage.getItem("mvUser"));
if (!user || user.role !== "cliente") {
  window.location.href = "index.html";
}

document.getElementById("clienteNome").textContent = user.nome;
document.getElementById("logoutBtn").onclick = () => {
  localStorage.removeItem("mvUser");
  window.location.href = "index.html";
};

// ===== ELEMENTOS =====
const listaEnderecos = document.getElementById("listaEnderecos");
const enderecoTitle = document.getElementById("enderecoTitle");
const enderecoForm = document.getElementById("enderecoForm");
const cancelEditBtn = document.getElementById("cancelEditBtn");

const apelido = document.getElementById("apelido");
const logradouro = document.getElementById("logradouro");
const numero = document.getElementById("numero");
const complemento = document.getElementById("complemento");
const bairro = document.getElementById("bairro");
const cidade = document.getElementById("cidade");
const uf = document.getElementById("uf");
const cep = document.getElementById("cep");
const referencia = document.getElementById("referencia");
const isPrincipal = document.getElementById("isPrincipal");

let enderecos = [];
let editingId = null;

// ===== CARREGAR ENDEREÇOS =====
async function carregarEnderecos() {
  try {
    const res = await fetch(`${API}/enderecos?cliente=${user.id}`);
    if (!res.ok) {
      listaEnderecos.innerHTML =
        `<p class="text-muted">Erro ao carregar endereços.</p>`;
      return;
    }
    enderecos = await res.json();
    renderEnderecos();
  } catch (err) {
    console.error("Erro carregarEnderecos", err);
    listaEnderecos.innerHTML =
      `<p class="text-muted">Erro ao carregar endereços.</p>`;
  }
}

carregarEnderecos();

// ===== RENDER LISTA =====
function renderEnderecos() {
  listaEnderecos.innerHTML = "";

  if (!enderecos.length) {
    listaEnderecos.innerHTML =
      `<p class="text-muted">Nenhum endereço cadastrado ainda.</p>`;
    return;
  }

  enderecos.forEach(e => {
    const div = document.createElement("div");
    div.className = "pedido-card";

    const linha1 = `
      <strong>${e.apelido || "Endereço"}</strong>
      ${e.is_principal ? '<span class="badge" style="margin-left:8px;">Principal</span>' : ""}
    `;

    const linha2 = `
      ${e.logradouro}, ${e.numero}${
      e.complemento ? " - " + e.complemento : ""
    }<br/>
      ${e.bairro} - ${e.cidade}/${e.uf} · CEP ${e.cep}<br/>
      ${e.referencia ? "Ref.: " + e.referencia : ""}
    `;

    div.innerHTML = `
      <div class="pedido-header">
        <div>${linha1}</div>
      </div>
      <div class="pedido-body">
        ${linha2}
      </div>
      <div style="display:flex; gap:8px; margin-top:6px;">
        <button class="small secondary" onclick="editarEndereco(${e.id_endereco})">Editar</button>
        <button class="small danger" onclick="excluirEndereco(${e.id_endereco})">Excluir</button>
        ${
          e.is_principal
            ? ""
            : `<button class="small" onclick="definirPrincipal(${e.id_endereco})">Tornar principal</button>`
        }
      </div>
    `;

    listaEnderecos.appendChild(div);
  });
}

// Expor funções globais
window.editarEndereco = function (id_endereco) {
  const e = enderecos.find(x => x.id_endereco === id_endereco);
  if (!e) return;

  editingId = id_endereco;
  enderecoTitle.textContent = `Editando endereço #${id_endereco}`;

  apelido.value = e.apelido || "";
  logradouro.value = e.logradouro || "";
  numero.value = e.numero || "";
  complemento.value = e.complemento || "";
  bairro.value = e.bairro || "";
  cidade.value = e.cidade || "";
  uf.value = e.uf || "";
  cep.value = e.cep || "";
  referencia.value = e.referencia || "";
  isPrincipal.checked = !!e.is_principal;

  cancelEditBtn.hidden = false;
};

window.excluirEndereco = async function (id_endereco) {
  if (!confirm("Deseja realmente excluir este endereço?")) return;

  try {
    const res = await fetch(`${API}/enderecos/${id_endereco}`, {
      method: "DELETE"
    });
    const body = await res.json().catch(() => ({}));

    if (!res.ok) {
      alert(body.error || "Erro ao excluir endereço.");
      return;
    }

    carregarEnderecos();
  } catch (err) {
    console.error("Erro excluirEndereco", err);
    alert("Erro ao conectar ao servidor.");
  }
};

window.definirPrincipal = async function (id_endereco) {
  try {
    const res = await fetch(`${API}/enderecos/${id_endereco}/principal`, {
      method: "PATCH"
    });
    const body = await res.json().catch(() => ({}));

    if (!res.ok) {
      alert(body.error || "Erro ao definir principal.");
      return;
    }

    carregarEnderecos();
  } catch (err) {
    console.error("Erro definirPrincipal", err);
    alert("Erro ao conectar ao servidor.");
  }
};

// ===== FORM SUBMIT =====
enderecoForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  const payload = {
    id_cliente: user.id,
    apelido: apelido.value.trim() || null,
    logradouro: logradouro.value.trim(),
    numero: numero.value.trim(),
    complemento: complemento.value.trim() || null,
    bairro: bairro.value.trim(),
    cidade: cidade.value.trim(),
    uf: uf.value.trim().toUpperCase(),
    cep: cep.value.trim(),
    referencia: referencia.value.trim() || null,
    is_principal: isPrincipal.checked ? 1 : 0
  };

  if (!payload.logradouro || !payload.numero || !payload.bairro || !payload.cidade || !payload.uf || !payload.cep) {
    alert("Preencha todos os campos obrigatórios.");
    return;
  }

  const url = editingId
    ? `${API}/enderecos/${editingId}`
    : `${API}/enderecos`;
  const method = editingId ? "PUT" : "POST";

  try {
    const res = await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    const body = await res.json().catch(() => ({}));

    if (!res.ok) {
      alert(body.error || "Erro ao salvar endereço.");
      return;
    }

    resetFormEndereco();
    carregarEnderecos();
  } catch (err) {
    console.error("Erro salvar endereço", err);
    alert("Erro ao conectar ao servidor.");
  }
});

function resetFormEndereco() {
  editingId = null;
  enderecoTitle.textContent = "Novo endereço";
  enderecoForm.reset();
  isPrincipal.checked = false;
  cancelEditBtn.hidden = true;
}

cancelEditBtn.addEventListener("click", () => {
  resetFormEndereco();
});
