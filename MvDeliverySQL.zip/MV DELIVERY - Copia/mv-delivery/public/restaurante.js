const API = location.origin + "/api";

// ======= VERIFICA SE É RESTAURANTE =======
const user = JSON.parse(localStorage.getItem("mvUser"));
if (!user || user.role !== "restaurante") {
  window.location.href = "index.html";
}

document.getElementById("restauranteNome").textContent = user.nome;

// logout
document.getElementById("logoutBtn").onclick = () => {
  localStorage.removeItem("mvUser");
  window.location.href = "index.html";
};

// ====================================================================
// ============================= PEDIDOS ===============================
// ====================================================================

const listaPedidos = document.getElementById("listaPedidos");
const detalhesCard = document.getElementById("detalhesPedido");

let pedidos = [];

// ========== CARREGAR PEDIDOS ==========
async function carregarPedidos() {
  try {
    const res = await fetch(`${API}/pedidos?restaurante=${user.id}`);
    if (!res.ok) {
      console.error("Erro ao buscar pedidos");
      return;
    }
    pedidos = await res.json();
    renderListaPedidos();
  } catch (err) {
    console.error("Erro carregarPedidos", err);
  }
}

carregarPedidos();
// Atualiza a cada 6s
setInterval(carregarPedidos, 6000);

// ========== LISTAR PEDIDOS ==========
function renderListaPedidos() {
  listaPedidos.innerHTML = "";

  if (!pedidos.length) {
    listaPedidos.innerHTML =
      `<p class="text-muted">Nenhum pedido por enquanto...</p>`;
    return;
  }

  pedidos.forEach(p => {
    const totalNum = Number(p.total || 0);

    const card = document.createElement("div");
    card.className = "pedido-card";

    card.innerHTML = `
      <div class="pedido-header">
        <strong>#${p.codigo_pedido || p.id_pedido}</strong>
        <span class="pedido-status ${p.status}">${p.status}</span>
      </div>
      <div class="pedido-body">
        Cliente: ${p.nome_cliente} <br/>
        Total: R$ ${totalNum.toFixed(2)} <br/>
        ${new Date(p.data_hora).toLocaleString()}
      </div>
    `;

    card.onclick = () => abrirPedido(p.id_pedido);

    listaPedidos.appendChild(card);
  });
}

// ========== ABRIR DETALHES DO PEDIDO ==========
async function abrirPedido(id_pedido) {
  try {
    const res = await fetch(`${API}/pedidos/${id_pedido}`);
    if (!res.ok) {
      detalhesCard.innerHTML = `<p class="text-muted">Erro ao carregar detalhes.</p>`;
      return;
    }
    const data = await res.json();
    const itens = data.itens || [];

    const subtotalNum = Number(data.pedido.subtotal || 0);
    const taxaNum = Number(data.pedido.taxa_entrega || 0);
    const totalNum = Number(data.pedido.total || 0);

    detalhesCard.innerHTML = `
      <h3>Pedido #${data.pedido.codigo_pedido || data.pedido.id_pedido}</h3>

      <p>
        <strong>Cliente:</strong> ${data.pedido.nome_cliente}<br/>
        <strong>Endereço:</strong> ${data.pedido.endereco_texto}<br/>
        <strong>Observações:</strong> ${data.pedido.observacoes || "Nenhuma"}<br/>
      </p>

      <h4>Itens</h4>
      ${itens.map(i => {
        const linhaNum = Number(i.total_linha || (i.preco_unitario * i.quantidade) || 0);
        return `
          <div class="carrinho-item">
            <span>${i.quantidade}x ${i.nome_item}</span>
            <strong>R$ ${linhaNum.toFixed(2)}</strong>
          </div>
        `;
      }).join("")}

      <h4 class="mt-12">Totais</h4>
      <div class="pedido-body">
        Subtotal: R$ ${subtotalNum.toFixed(2)}<br/>
        Taxa de entrega: R$ ${taxaNum.toFixed(2)}<br/>
        <strong>Total: R$ ${totalNum.toFixed(2)}</strong>
      </div>

      <h4 class="mt-12">Status do pedido</h4>
      <select id="statusSelect">
        <option value="novo">novo</option>
        <option value="em_preparo">em_preparo</option>
        <option value="a_caminho">a_caminho</option>
        <option value="entregue">entregue</option>
        <option value="cancelado">cancelado</option>
      </select>

      <button class="full-width mt-12" id="btnSalvarStatus">Salvar Status</button>
    `;

    document.getElementById("statusSelect").value = data.pedido.status;
    document.getElementById("btnSalvarStatus").onclick = () => {
      salvarStatus(data.pedido.id_pedido);
    };
  } catch (err) {
    console.error("Erro abrirPedido", err);
    detalhesCard.innerHTML = `<p class="text-muted">Erro ao carregar detalhes.</p>`;
  }
}

// ========== ATUALIZAR STATUS ==========
async function salvarStatus(id_pedido) {
  const novoStatus = document.getElementById("statusSelect").value;

  try {
    const res = await fetch(`${API}/pedidos/${id_pedido}/status`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: novoStatus })
    });

    if (!res.ok) {
      alert("Erro ao atualizar status.");
      return;
    }

    alert("Status atualizado!");
    carregarPedidos();
  } catch (err) {
    console.error(err);
    alert("Erro ao conectar com o servidor.");
  }
}

// ====================================================================
// =========================== CARDÁPIO ================================
// ====================================================================

const listaCardapioRest = document.getElementById("listaCardapioRest");
const cardapioTitle = document.getElementById("cardapioTitle");
const cardapioForm = document.getElementById("cardapioForm");
const nomeItem = document.getElementById("nomeItem");
const descricaoItem = document.getElementById("descricaoItem");
const categoriaItem = document.getElementById("categoriaItem");
const precoItem = document.getElementById("precoItem");
const ativoItem = document.getElementById("ativoItem");
const cardapioCancelBtn = document.getElementById("cardapioCancelBtn");

let cardapio = [];
let editingItemId = null;

// Carrega itens do cardápio do restaurante logado
async function carregarCardapio() {
  try {
    const res = await fetch(`${API}/cardapio/restaurante/${user.id}`);
    if (!res.ok) {
      console.error("Erro ao carregar cardápio");
      return;
    }
    cardapio = await res.json();
    renderCardapio();
  } catch (err) {
    console.error("Erro carregarCardapio", err);
  }
}

carregarCardapio();

// Renderiza lista de itens do cardápio
function renderCardapio() {
  listaCardapioRest.innerHTML = "";

  if (!cardapio.length) {
    listaCardapioRest.innerHTML =
      `<p class="text-muted">Nenhum item no cardápio. Adicione o primeiro!</p>`;
    return;
  }

  cardapio.forEach(item => {
    const precoNum = Number(item.preco || 0);

    const div = document.createElement("div");
    div.className = "cardapio-item";

    div.innerHTML = `
      <div class="cardapio-info">
        <div class="cardapio-nome">${item.nome}</div>
        <div class="cardapio-desc">
          ${item.descricao || ""} ${item.categoria ? `· ${item.categoria}` : ""}
        </div>
        <div class="cardapio-preco">
          R$ ${precoNum.toFixed(2)}
          ${item.ativo ? '<span class="badge">Ativo</span>' : '<span class="badge">Inativo</span>'}
        </div>
      </div>
      <div style="display:flex; flex-direction:column; gap:4px;">
        <button class="small secondary" onclick="editarItem(${item.id_item})">Editar</button>
        <button class="small danger" onclick="excluirItem(${item.id_item})">Excluir</button>
      </div>
    `;

    listaCardapioRest.appendChild(div);
  });
}

// Expor funções pro HTML inline
window.editarItem = function (id_item) {
  const item = cardapio.find(i => i.id_item === id_item);
  if (!item) return;

  editingItemId = id_item;
  cardapioTitle.textContent = `Editando item #${id_item}`;

  nomeItem.value = item.nome || "";
  descricaoItem.value = item.descricao || "";
  categoriaItem.value = item.categoria || "";
  precoItem.value = Number(item.preco || 0);
  ativoItem.checked = !!item.ativo;

  cardapioCancelBtn.hidden = false;
};

window.excluirItem = async function (id_item) {
  if (!confirm("Deseja realmente excluir este item do cardápio?")) return;

  try {
    const res = await fetch(`${API}/cardapio/${id_item}`, {
      method: "DELETE"
    });

    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      alert(body.error || "Erro ao excluir item.");
      return;
    }

    carregarCardapio();
  } catch (err) {
    console.error("Erro excluirItem", err);
    alert("Erro ao conectar ao servidor.");
  }
};

// Resetar form de cardápio
function resetFormCardapio() {
  editingItemId = null;
  cardapioTitle.textContent = "Novo item";
  cardapioForm.reset();
  ativoItem.checked = true;
  cardapioCancelBtn.hidden = true;
}

// Salvar item (novo ou edição)
cardapioForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  const payload = {
    id_restaurante: user.id,
    nome: nomeItem.value.trim(),
    descricao: descricaoItem.value.trim() || null,
    categoria: categoriaItem.value.trim() || null,
    preco: Number(precoItem.value),
    ativo: ativoItem.checked ? 1 : 0
  };

  if (!payload.nome || isNaN(payload.preco)) {
    alert("Informe nome e preço válidos.");
    return;
  }

  const url = editingItemId
    ? `${API}/cardapio/${editingItemId}`
    : `${API}/cardapio`;
  const method = editingItemId ? "PUT" : "POST";

  try {
    const res = await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    const body = await res.json().catch(() => ({}));

    if (!res.ok) {
      alert(body.error || "Erro ao salvar item de cardápio.");
      return;
    }

    resetFormCardapio();
    carregarCardapio();
  } catch (err) {
    console.error("Erro salvar item cardápio", err);
    alert("Erro ao conectar ao servidor.");
  }
});

cardapioCancelBtn.addEventListener("click", () => {
  resetFormCardapio();
});
