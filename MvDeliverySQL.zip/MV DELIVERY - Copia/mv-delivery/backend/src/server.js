import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

import { authRouter } from "./authRoutes.js";
import { clienteRouter } from "./clienteRoutes.js";
import { restauranteRouter } from "./restauranteRoutes.js";
import { cardapioRouter } from "./cardapioRoutes.js";
import { pedidoRouter } from "./pedidoRoutes.js";
import { adminRouter } from "./adminRoutes.js";
import { enderecoRouter } from "./enderecoRoutes.js";


dotenv.config();

const app = express();

app.use(cors());
app.use(express.json());

// Rotas API
app.use("/api/auth", authRouter);
app.use("/api/clientes", clienteRouter);
app.use("/api/restaurantes", restauranteRouter);
app.use("/api/cardapio", cardapioRouter);
app.use("/api/pedidos", pedidoRouter);
app.use("/api/admin", adminRouter);
app.use("/api/enderecos", enderecoRouter);


// ====== SERVIR FRONTEND DA PASTA /public ======
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// sobe de src/ -> backend/ -> raiz -> public
const publicDir = path.join(__dirname, "../../public");

// arquivos estáticos (HTML, CSS, JS)
app.use(express.static(publicDir));

// rota raiz -> index.html
app.get("/", (req, res) => {
  res.sendFile(path.join(publicDir, "index.html"));
});
// ==============================================

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`🔥 MV Delivery backend rodando em http://localhost:${PORT}`);
}).on("error", (err) => {
  if (err.code === "EADDRINUSE") {
    console.error(`❌ ERRO: Porta ${PORT} já está em uso.`);
  } else {
    console.error(err);
  }
});
