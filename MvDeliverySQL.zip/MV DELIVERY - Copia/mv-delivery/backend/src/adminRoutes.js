// backend/src/adminRoutes.js
import express from "express";
import { pool } from "./db.js";

export const adminRouter = express.Router();

/**
 * Mapeamento das entidades que o admin pode manipular
 * (pra não deixar qualquer tabela exposta).
 */
const ENTITIES = {
  cliente: {
    table: "cliente",
    pk: "id_cliente",
    fields: ["nome", "email", "telefone", "cpf", "senha_hash"]
  },
  restaurante: {
    table: "restaurante",
    pk: "id_restaurante",
    fields: ["nome", "email", "telefone", "tipo_cozinha", "endereco", "senha_hash", "status"]
  },
  endereco_cliente: {
    table: "endereco_cliente",
    pk: "id_endereco",
    fields: [
      "id_cliente",
      "apelido",
      "logradouro",
      "numero",
      "complemento",
      "bairro",
      "cidade",
      "uf",
      "cep",
      "referencia",
      "is_principal"
    ]
  },
  cardapio_item: {
    table: "cardapio_item",
    pk: "id_item",
    fields: ["id_restaurante", "nome", "descricao", "categoria", "preco", "ativo"]
  },
  pedido: {
    table: "pedido",
    pk: "id_pedido",
    fields: [
      "id_cliente",
      "id_restaurante",
      "id_endereco",
      "endereco_texto",
      "observacoes",
      "status",
      "subtotal",
      "taxa_entrega",
      "total"
    ]
  },
  item_pedido: {
    table: "item_pedido",
    pk: "id_item_pedido",
    fields: ["id_pedido", "id_item", "nome_item", "quantidade", "preco_unitario", "total_linha"]
  },
  avaliacao: {
    table: "avaliacao",
    pk: "id_avaliacao",
    fields: ["id_pedido", "id_cliente", "id_restaurante", "nota", "comentario"]
  }
};

function resolveEntity(entityName, res) {
  const ent = ENTITIES[entityName];
  if (!ent) {
    res.status(400).json({ error: "Entidade não permitida para admin." });
    return null;
  }
  return ent;
}

// ===== LISTAR (GET /api/admin/:entity?limit=100) =====
adminRouter.get("/:entity", async (req, res) => {
  const ent = resolveEntity(req.params.entity, res);
  if (!ent) return;

  const limit = Number(req.query.limit) || 100;

  try {
    const [rows] = await pool.query(
      `SELECT * FROM ${ent.table} ORDER BY ${ent.pk} DESC LIMIT ?`,
      [limit]
    );
    res.json(rows);
  } catch (err) {
    console.error("ADMIN LIST", err);
    res.status(500).json({ error: "Erro ao listar registros." });
  }
});

// ===== DETALHE (GET /api/admin/:entity/:id) =====
adminRouter.get("/:entity/:id", async (req, res) => {
  const ent = resolveEntity(req.params.entity, res);
  if (!ent) return;

  const { id } = req.params;
  try {
    const [rows] = await pool.query(
      `SELECT * FROM ${ent.table} WHERE ${ent.pk} = ?`,
      [id]
    );
    if (!rows.length) {
      return res.status(404).json({ error: "Registro não encontrado." });
    }
    res.json(rows[0]);
  } catch (err) {
    console.error("ADMIN DETAIL", err);
    res.status(500).json({ error: "Erro ao buscar registro." });
  }
});

// ===== INSERIR (POST /api/admin/:entity) =====
adminRouter.post("/:entity", async (req, res) => {
  const ent = resolveEntity(req.params.entity, res);
  if (!ent) return;

  const data = req.body || {};
  const cols = [];
  const vals = [];

  for (const f of ent.fields) {
    if (data[f] !== undefined) {
      cols.push(f);
      vals.push(data[f]);
    }
  }

  if (!cols.length) {
    return res.status(400).json({ error: "Nenhum campo válido para inserção." });
  }

  const placeholders = cols.map(() => "?").join(",");

  try {
    const [r] = await pool.query(
      `INSERT INTO ${ent.table} (${cols.join(",")}) VALUES (${placeholders})`,
      vals
    );
    res.status(201).json({ [ent.pk]: r.insertId });
  } catch (err) {
    console.error("ADMIN INSERT", err);
    res.status(500).json({ error: "Erro ao inserir registro." });
  }
});

// ===== ATUALIZAR (PUT /api/admin/:entity/:id) =====
adminRouter.put("/:entity/:id", async (req, res) => {
  const ent = resolveEntity(req.params.entity, res);
  if (!ent) return;

  const data = req.body || {};
  const { id } = req.params;

  const sets = [];
  const vals = [];

  for (const f of ent.fields) {
    if (data[f] !== undefined) {
      sets.push(`${f} = ?`);
      vals.push(data[f]);
    }
  }

  if (!sets.length) {
    return res.status(400).json({ error: "Nenhum campo válido para atualização." });
  }

  vals.push(id);

  try {
    const [r] = await pool.query(
      `UPDATE ${ent.table} SET ${sets.join(", ")} WHERE ${ent.pk} = ?`,
      vals
    );
    if (!r.affectedRows) {
      return res.status(404).json({ error: "Registro não encontrado." });
    }
    res.json({ ok: true });
  } catch (err) {
    console.error("ADMIN UPDATE", err);
    res.status(500).json({ error: "Erro ao atualizar registro." });
  }
});

// ===== REMOVER (DELETE /api/admin/:entity/:id) =====
adminRouter.delete("/:entity/:id", async (req, res) => {
  const ent = resolveEntity(req.params.entity, res);
  if (!ent) return;

  const { id } = req.params;

  try {
    const [r] = await pool.query(
      `DELETE FROM ${ent.table} WHERE ${ent.pk} = ?`,
      [id]
    );
    if (!r.affectedRows) {
      return res.status(404).json({ error: "Registro não encontrado." });
    }
    res.json({ ok: true });
  } catch (err) {
    console.error("ADMIN DELETE", err);
    res.status(500).json({ error: "Erro ao remover registro." });
  }
});
