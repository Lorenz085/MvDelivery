// backend/src/pedidoRoutes.js
import express from "express";
import { pool } from "./db.js";

export const pedidoRouter = express.Router();

/**
 * Gera um código de pedido de 4 dígitos (1000–9999)
 */
function gerarCodigoPedido() {
  return String(Math.floor(1000 + Math.random() * 9000));
}

/**
 * POST /api/pedidos/checkout
 * Fecha um pedido para um cliente em um restaurante.
 * body:
 *  - id_cliente
 *  - id_restaurante
 *  - endereco_texto
 *  - id_endereco (opcional)
 *  - observacoes (opcional)
 *  - taxa_entrega
 *  - itens: [{ id_item, nome_item, preco_unitario|preco, quantidade }]
 */
pedidoRouter.post("/checkout", async (req, res) => {
  const {
    id_cliente,
    id_restaurante,
    endereco_texto,
    id_endereco,
    observacoes,
    taxa_entrega,
    itens
  } = req.body;

  if (!id_cliente || !id_restaurante || !endereco_texto) {
    return res
      .status(400)
      .json({ error: "id_cliente, id_restaurante e endereco_texto são obrigatórios." });
  }

  if (!Array.isArray(itens) || !itens.length) {
    return res.status(400).json({ error: "Nenhum item informado no pedido." });
  }

  const taxa = Number(taxa_entrega) || 0;

  let subtotal = 0;
  const itensNormalizados = [];

  for (const it of itens) {
    const qtd = Number(it.quantidade || 0);
    const preco = Number(
      it.preco_unitario !== undefined ? it.preco_unitario : it.preco
    );

    if (!qtd || isNaN(preco)) continue;

    const totalLinha = qtd * preco;
    subtotal += totalLinha;

    itensNormalizados.push({
      id_item: it.id_item || null,
      nome_item: it.nome_item || it.nome,
      quantidade: qtd,
      preco_unitario: preco,
      total_linha: totalLinha
    });
  }

  if (!itensNormalizados.length || subtotal <= 0) {
    return res.status(400).json({ error: "Itens inválidos no pedido." });
  }

  const total = subtotal + taxa;
  const codigoPedido = gerarCodigoPedido();

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    // Insere pedido
    const [pr] = await conn.query(
      `INSERT INTO pedido
       (id_cliente,
        id_restaurante,
        id_endereco,
        endereco_texto,
        observacoes,
        status,
        subtotal,
        taxa_entrega,
        total,
        codigo_pedido,
        data_hora)
       VALUES (?,?,?,?,?,'novo',?,?,?,?, NOW())`,
      [
        id_cliente,
        id_restaurante,
        id_endereco || null,
        endereco_texto,
        observacoes || null,
        subtotal,
        taxa,
        total,
        codigoPedido
      ]
    );

    const id_pedido = pr.insertId;

    // Insere itens
    for (const it of itensNormalizados) {
      await conn.query(
        `INSERT INTO item_pedido
         (id_pedido, id_item, nome_item, quantidade, preco_unitario, total_linha)
         VALUES (?,?,?,?,?,?)`,
        [
          id_pedido,
          it.id_item,
          it.nome_item,
          it.quantidade,
          it.preco_unitario,
          it.total_linha
        ]
      );
    }

    await conn.commit();
    res.status(201).json({
      id_pedido,
      codigo_pedido: codigoPedido,
      subtotal,
      total
    });
  } catch (err) {
    console.error("CHECKOUT ERRO", err);
    await conn.rollback();
    res.status(500).json({ error: "Erro ao finalizar pedido." });
  } finally {
    conn.release();
  }
});

/**
 * GET /api/pedidos?restaurante=ID
 * GET /api/pedidos?cliente=ID
 * Lista pedidos por restaurante ou por cliente.
 */
pedidoRouter.get("/", async (req, res) => {
  const { restaurante, cliente } = req.query;

  let where = "";
  const params = [];

  if (restaurante) {
    where = "WHERE p.id_restaurante = ?";
    params.push(restaurante);
  } else if (cliente) {
    where = "WHERE p.id_cliente = ?";
    params.push(cliente);
  }

  const sql = `
    SELECT
      p.id_pedido,
      p.codigo_pedido,
      p.status,
      p.total,
      p.subtotal,
      p.taxa_entrega,
      p.data_hora,
      c.nome AS nome_cliente,
      r.nome AS nome_restaurante
    FROM pedido p
    JOIN cliente c      ON c.id_cliente      = p.id_cliente
    JOIN restaurante r  ON r.id_restaurante  = p.id_restaurante
    ${where}
    ORDER BY p.data_hora DESC, p.id_pedido DESC
  `;

  try {
    const [rows] = await pool.query(sql, params);
    res.json(rows);
  } catch (err) {
    console.error("LISTAR PEDIDOS ERRO", err);
    res.status(500).json({ error: "Erro ao listar pedidos." });
  }
});

/**
 * GET /api/pedidos/:id
 * Detalhes de um pedido (cabeçalho + itens)
 */
pedidoRouter.get("/:id_pedido", async (req, res) => {
  const { id_pedido } = req.params;

  try {
    const [pRows] = await pool.query(
      `
      SELECT
        p.*,
        c.nome AS nome_cliente,
        r.nome AS nome_restaurante
      FROM pedido p
      JOIN cliente c     ON c.id_cliente     = p.id_cliente
      JOIN restaurante r ON r.id_restaurante = p.id_restaurante
      WHERE p.id_pedido = ?
      `,
      [id_pedido]
    );

    if (!pRows.length) {
      return res.status(404).json({ error: "Pedido não encontrado." });
    }

    const [itRows] = await pool.query(
      `
      SELECT
        id_item_pedido,
        id_item,
        nome_item,
        quantidade,
        preco_unitario,
        total_linha
      FROM item_pedido
      WHERE id_pedido = ?
      ORDER BY id_item_pedido
      `,
      [id_pedido]
    );

    res.json({ pedido: pRows[0], itens: itRows });
  } catch (err) {
    console.error("DETALHE PEDIDO ERRO", err);
    res.status(500).json({ error: "Erro ao buscar detalhes do pedido." });
  }
});

/**
 * PATCH /api/pedidos/:id/status
 * Atualiza apenas o status do pedido.
 * body: { status }
 */
pedidoRouter.patch("/:id_pedido/status", async (req, res) => {
  const { id_pedido } = req.params;
  const { status } = req.body;

  const allowed = ["novo", "em_preparo", "a_caminho", "entregue", "cancelado"];
  if (!allowed.includes(status)) {
    return res.status(400).json({ error: "Status inválido." });
  }

  try {
    const [r] = await pool.query(
      `UPDATE pedido SET status = ? WHERE id_pedido = ?`,
      [status, id_pedido]
    );

    if (!r.affectedRows) {
      return res.status(404).json({ error: "Pedido não encontrado." });
    }

    res.json({ ok: true });
  } catch (err) {
    console.error("STATUS PEDIDO ERRO", err);
    res.status(500).json({ error: "Erro ao atualizar status do pedido." });
  }
});
